from datetime import date
from PyQt5.QtCore import QPoint
from PyQt5.QtWidgets import QWidget, QHBoxLayout, QDesktopWidget, QLabel
from PyQt5.QtGui import QResizeEvent
from utils import QUtilsWidget, QImageButton


class RawTitleBar(QWidget, QUtilsWidget):
    def __init__(self, parent):
        super().__init__()

        self.parent = parent
        self.mainwindow = parent

        self.setGeometry(0, 0, self.parent.width(), 15)
        self.setFixedHeight(15)

        self.fill_background((128, 128, 128))

        self.start = QPoint(0, 0)
        self.pressed = False
        self.pressing = False
        self.maximized = False
        self.old_size = None

        self.layout = QHBoxLayout()
        self.layout.setContentsMargins(0, 0, 0, 0)

        self.setLayout(self.layout)

    def mousePressEvent(self, event):
        self.start = self.mapToGlobal(event.pos())
        self.pressing = True

    def mouseReleaseEvent(self, event):
        self.pressing = False

    def mouseMoveEvent(self, event):
        if self.pressing:
            end = self.mapToGlobal(event.pos())
            self.movement = end - self.start
            self.parent.setGeometry(self.mapToGlobal(self.movement).x(),
                                    self.mapToGlobal(self.movement).y(),
                                    self.parent.width(),
                                    self.parent.height())
            self.start = end


class TitleBar(QWidget, QUtilsWidget):
    def __init__(self, parent):
        super().__init__()

        self.parent = parent
        self.mainwindow = parent

        self.setGeometry(0, 0, self.parent.width(), 30)
        self.setFixedHeight(30)

        self.start = QPoint(0, 0)
        self.pressed = False
        self.pressing = False
        self.maximized = False
        self.old_size = None

        self.layout = QHBoxLayout()
        self.layout.setContentsMargins(0, 0, 0, 0)
        self.layout.setSpacing(0)

        w, h = 47, 30

        self.close_button = QImageButton("data/close_normal.png", "data/close_pressed.png")
        self.close_button.resize(w, h)
        @self.close_button.clicked.connect
        def clicked():
            try:
                self.mainwindow.terminal.editor_windows.pop(self.mainwindow.id)
            except:
                self.mainwindow.terminal.editor_windows.pop(len(self.mainwindow.terminal.editor_windows)-1)
            #a = self.mainwindow.id
            a = len(self.mainwindow.terminal.editor_windows)
            if a+1 == 1: self.mainwindow.terminal.page_one.hide()
            elif a+1 == 2: self.mainwindow.terminal.page_two.hide()
            elif a+1 == 3: self.mainwindow.terminal.page_three.hide()
            elif a+1 == 4: self.mainwindow.terminal.page_four.hide()
            elif a+1 == 5: self.mainwindow.terminal.page_five.hide()
            self.mainwindow.terminal.pages -= 1
            self.mainwindow.close()

        self.min_button = QImageButton("data/tab_normal.png", "data/tab_pressed.png")
        self.min_button.resize(w, h)
        @self.min_button.clicked.connect
        def clicked(): self.mainwindow.showMinimized()

        self.max_button = QImageButton("data/resize_normal.png", "data/resize_pressed.png")
        self.max_button.resize(w, h)
        @self.max_button.clicked.connect
        def clicked():
            if self.maximized:
                #Eski konumuna geri dönsün, 200 100 'e değil
                #self.parent.resize(self.old_size[0], self.old_size[1])
                self.mainwindow.setGeometry(200, 100, self.old_size[0], self.old_size[1])

                self.maximized = False
            else:
                self.old_size = self.parent.width(), self.parent.height()
                self.old_size_ = self.parent.size()
                screen = QDesktopWidget().availableGeometry()
                #self.parent.resize(screen.width(), screen.height())
                self.mainwindow.setGeometry(0, 0, screen.width(), screen.height())
                self.mainwindow.resizeEvent(QResizeEvent(self.mainwindow.size(), self.old_size_))

                self.maximized = True

        ver = QLabel(date.today().strftime("%d.%m.%Y"))
        ver.setStyleSheet(f"color:#fff; font-size:15px;")
        ver.setFixedWidth(140)
        ver.setContentsMargins(15, 0, 0, 0)

        self.spac = QWidget()
        self.spac.setFixedWidth(self.parent.width() - 140 - 140)

        self.layout.addWidget(ver)
        self.layout.addWidget(self.spac)
        self.layout.addWidget(self.min_button)
        self.layout.addWidget(self.max_button)
        self.layout.addWidget(self.close_button)

        self.setLayout(self.layout)

    def resizeEvent(self, event):
        self.spac.setFixedWidth(self.parent.width() - 140 - 140)

    def mousePressEvent(self, event):
        self.start = self.mapToGlobal(event.pos())
        self.pressing = True

    def mouseReleaseEvent(self, event):
        self.pressing = False

    def mouseMoveEvent(self, event):
        if self.pressing:
            end = self.mapToGlobal(event.pos())
            self.movement = end - self.start
            self.parent.setGeometry(self.mapToGlobal(self.movement).x(),
                                    self.mapToGlobal(self.movement).y(),
                                    self.parent.width(),
                                    self.parent.height())
            self.start = end

import threading
import requests
from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import QWidget, QAbstractButton, QLabel, QPushButton
from PyQt5.QtCore import QRectF, QThread
from PyQt5.QtGui import QColor, QPainterPath, QPainter, QRegion, QPixmap, QPen


class QUtilsWidget:
    def __init__(self):
        self.last_radius = None

    def round_corners(self, radius=None):
        path = QPainterPath()
        if radius == None:
            path.addRoundedRect(QRectF(self.rect()), self.last_radius, self.last_radius)
        else:
            path.addRoundedRect(QRectF(self.rect()), radius, radius)
            self.last_radius = radius
        mask = QRegion(path.toFillPolygon().toPolygon())
        self.setMask(mask)

    def fill_background(self, color):
        self.setAutoFillBackground(True)
        p = self.palette()
        if isinstance(color, QColor):
            p.setColor(self.backgroundRole(), color)
        else:
            p.setColor(self.backgroundRole(), QColor(*color))
        self.setPalette(p)


class QImageButton(QAbstractButton):
    def __init__(self, filename, filename_pressed=None):
        super().__init__()
        self.pixmap = QPixmap(filename)
        if filename_pressed:
            self.pixmap_pressed = QPixmap(filename_pressed)
        else:
            self.pixmap_pressed = QPixmap(filename)
        self.pressing = False

    def paintEvent(self, event):
        painter = QPainter(self)
        if self.pressing:
            painter.drawPixmap(event.rect(), self.pixmap_pressed)
        else:
            painter.drawPixmap(event.rect(), self.pixmap)

    def resize(self, width, height):
        self.setFixedSize(width, height)
        self.pixmap = self.pixmap.scaled(height, width, transformMode=Qt.SmoothTransformation)
        self.pixmap_pressed = self.pixmap_pressed.scaled(width, height, transformMode=Qt.SmoothTransformation)

    def mousePressEvent(self, event):
        self.pressing = True
        super().mousePressEvent(event)

    def mouseReleaseEvent(self, event):
        self.pressing = False
        super().mouseReleaseEvent(event)

    def sizeHint(self):
        return self.pixmap.size()
